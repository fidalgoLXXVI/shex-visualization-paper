# 3DShEx

3DShEx is a visualization tool for Shape Expressions which generates a 3D force graph in a navigable environment.

## Install

Install with the following command:

```
npm install 3dshex
```

